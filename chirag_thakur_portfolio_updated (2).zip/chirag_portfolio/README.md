# Thakur Chirag — Personal Portfolio

A responsive, single-page premium dark portfolio website built with plain HTML, CSS and JavaScript.

## Preview locally
1. Extract the ZIP.
2. Open `index.html` in a browser.

## Before publishing
- LinkedIn: https://www.linkedin.com/in/thakur-chirag-0773a5179/
- Email: mrchirag.work@gmail.com
- WhatsApp: +91 78743 28610
- Add a professional headshot if you want one; the current initials tile is an intentional placeholder.
- Verify the role chronology, experience duration and achievement figures against your latest CV.
- Add your final resume PDF and link it from the hero section if desired.

## Publish at chiragthakur.com
You will need to register the domain (if not already owned) and choose a static host such as GitHub Pages, Netlify or Cloudflare Pages. Upload the contents of this folder, then connect the domain using the host's DNS instructions. DNS settings vary by provider.

## Files
- `index.html` — complete website source (responsive layout and interactions).
